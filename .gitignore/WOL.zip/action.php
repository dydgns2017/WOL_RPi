﻿<?php
$PORT=4000;
$MAC = $_POST["MAC"];
if(empty($MAC)==true){
	print " <script language=javascript> alert('맥 주소를 입력해주세요.'); history.go(-1); </script>";
}
else {
	system("bash WOL.sh $MAC");
	echo "전송완료";
}
?>