<html>
<head>
<style>
</style>
<meta charset="utf-8">
<title>Wake On LAN with RPi</title>
</head>
<body>
<form action="action.php" method="post">
<input type="text" name="MAC">
<input type="submit" value="ON">
</form>
</body>
</html>